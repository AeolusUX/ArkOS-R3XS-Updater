#!/bin/bash

if [[ "$(stat -c "%U" /home/ark)" != "ark" ]]; then
  printf "Fixing home folder permissions.  Please wait..."
  sudo chown -R ark:ark /home/ark
  sudo chmod -R 755 /home/ark
fi

printf "\nChecking for updates.  Please wait..."

LOG_FILE="/home/ark/esupdate.log"


if [ -f "$LOG_FILE" ]; then
  sudo rm "$LOG_FILE"
fi

sudo timedatectl set-ntp 1

LOCATION="https://raw.githubusercontent.com/AeolusUX/ArkOS-R3XS-Updater/main"
#BLOCATION="https://raw.githack.com/christianhaitian/arkos/main"
CLOCATION="https://raw.githubusercontent.com/AeolusUX/ArkOS-R3XS-Updater/main"

ISITCHINA=$(curl -s --connect-timeout 30 -m 60 http://demo.ip-api.com/json | grep -Po '"country":.*?[^\\]"')
if [ -z "$ISITCHINA" ]; then
  ISITCHINA=$(curl -s --connect-timeout 30 -m 60 https://api.iplocation.net/?ip=$(curl -s --connect-timeout 30 -m 60 checkip.amazonaws.com) | grep -Po '"country_name":.*?[^\\]"')
fi

if [[ "$ISITCHINA" == "\"country\":\"China\"" ]] || [[ "$ISITCHINA" == "\"country_name\":\"China\"" ]]; then
  printf "\n\nSwitching to China server for updates.\n\n" | tee -a "$LOG_FILE"
  LOCATION="$CLOCATION"
fi

if [[ "$LOCATION" != "$CLOCATION" ]]; then
  wget -t 3 -T 60 --no-check-certificate "$LOCATION"/LICENSE -O /dev/shm/LICENSE -a "$LOG_FILE"
  if [ $? -ne 0 ]; then
    LOCATION="$CLOCATION"
    wget -t 3 -T 60 --no-check-certificate "$LOCATION"/LICENSE -O /dev/shm/LICENSE -a "$LOG_FILE"
	if [ $? -ne 0 ]; then
      sudo msgbox "Looks like OTA updating is currently down or your wifi or internet connection is not functioning correctly."
      printf "There was an error with attempting this update." | tee -a "$LOG_FILE"
	  exit 1
    fi
  fi
fi

wget -t 3 -T 60 --no-check-certificate "$LOCATION"/ArkOSUpdate.sh -O /home/ark/ArkOSUpdate.sh -a "$LOG_FILE" || sudo rm -f /home/ark/ArkOSUpdate.sh | tee -a "$LOG_FILE"
if [ $? -ne 0 ]; then
  sudo msgbox "Looks like OTA updating is currently down or your wifi or internet connection is not functioning correctly."
  printf "There was an error with attempting this update." | tee -a "$LOG_FILE"
  exit 1
fi

sudo chmod -v 777 /home/ark/ArkOSUpdate.sh | tee -a "$LOG_FILE"
sed -i "/LOCATION\=\"http:\/\/gitcdn.link\/cdn\/christianhaitian\/arkos\/main\"/c\LOCATION\=\"$LOCATION\"" /home/ark/ArkOSUpdate.sh
sed -i -e '/ISITCHINA\=/,+5d' /home/ark/ArkOSUpdate.sh
sh /home/ark/ArkOSUpdate.sh

if [ $? -ne 187 ]; then
  sudo msgbox "There was an error with attempting this update.  Did you make sure to enable your wifi and connect to a wifi network?  If so, enable remote services in options and try to update again."
  printf "There was an error with attempting this update." | tee -a "$LOG_FILE"
fi

if [ ! -z $(pidof rg351p-js2xbox) ]; then
  sudo kill -9 $(pidof rg351p-js2xbox)
  sudo rm /dev/input/by-path/platform-odroidgo2-joypad-event-joystick
fi
