#!/bin/bash
sudo systemctl disable play-video.service
sudo systemctl restart emulationstation
