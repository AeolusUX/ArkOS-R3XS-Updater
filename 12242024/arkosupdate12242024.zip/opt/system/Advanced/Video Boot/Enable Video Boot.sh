#!/bin/bash
sudo systemctl enable play-video.service
sudo systemctl restart emulationstation
