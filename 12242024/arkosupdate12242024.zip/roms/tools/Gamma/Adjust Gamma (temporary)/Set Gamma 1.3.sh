#!/bin/sh 
cd "$(dirname "$0")"
../gamma -s "1.3"
