#!/bin/sh 
cd "$(dirname "$0")"
../gamma -s "0.5"
