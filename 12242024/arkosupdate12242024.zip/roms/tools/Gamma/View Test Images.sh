#!/bin/sh
cd "$(dirname "$0")"
retroarch images/gamma.png
