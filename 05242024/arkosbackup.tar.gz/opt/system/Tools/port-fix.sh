#!/bin/bash
sudo chmod -R 755 /usr/local/bin/
sudo rm -f /opt/system/Tools/port-fix.sh
printf "Rebooting now..."
sleep 3
sudo reboot
