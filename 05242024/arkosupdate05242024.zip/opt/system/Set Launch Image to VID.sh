#!/bin/bash

# List of files to delete
files_to_delete=(
  "/home/ark/.config/.LOADING_IMAGE"
  "/home/ark/.config/.LOADING_IMAGE_MARQUEE"
  "/home/ark/.config/.LOADING_IMAGE_IMAGE"
  "/home/ark/.config/.LOADING_IMAGE_THUMB"
  "/home/ark/.config/.GameLoadingIModeGIF"
)

# Delete the specified files if they exist
for file in "${files_to_delete[@]}"; do
  if [ -e "$file" ]; then
    rm "$file"
    echo "Deleted $file"
  fi
done

# Create the .GameLoadingIModeVID file
touch /home/ark/.config/.GameLoadingIModeVID
echo "Created /home/ark/.config/.GameLoadingIModeVID"
