#!/bin/bash

# List of files to delete
files_to_delete=(
  "/home/ark/.config/.LOADING_IMAGE_MARQUEE"
  "/home/ark/.config/.LOADING_IMAGE_IMAGE"
  "/home/ark/.config/.LOADING_IMAGE_THUMB"
  "/home/ark/.config/.GameLoadingIModeVID"
  "/home/ark/.config/.GameLoadingIModeGIF"
)

# Delete the specified files if they exist
for file in "${files_to_delete[@]}"; do
  if [ -e "$file" ]; then
    sudo rm "$file"
    echo "Deleted $file"
  fi
done

# Create the .LOADING_IMAGE file
sudo touch /home/ark/.config/.LOADING_IMAGE
echo "Created /home/ark/.config/.LOADING_IMAGE"

# Inform user and add a pause
echo "Set Launch Image to PIC"
sleep 3

# Check and rename "Set Launch Image to PIC" if exists
if [ -e "Set Launch Image to PIC" ]; then
  sudo mv "Set Launch Image to GIF" "Set Launch Image to GIF.sh"
fi

# Check and rename "Set Launch Image to MP4" if exists
if [ -e "Set Launch Image to MP4" ]; then
  sudo mv "Set Launch Image to MP4" "Set Launch Image to VID.sh"
fi

# Rename the script
sudo mv "$0" "Set Launch Image to PIC"