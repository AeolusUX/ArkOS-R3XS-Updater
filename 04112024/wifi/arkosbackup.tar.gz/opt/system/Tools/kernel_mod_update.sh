#!/bin/bash
sudo depmod -a
sudo rm -f /opt/system/Tools/kernel_mod_update.sh
printf "Rebooting now..."
sleep 3
sudo reboot
