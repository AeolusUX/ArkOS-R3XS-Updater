#!/bin/bash

DEVICE=""

if [ -f "/boot/rk3326-rg351mp-linux.dtb" ] || [ -f "/boot/rk3326-r35s-linux.dtb" ] || [ -f "/boot/rk3326-r36s-linux.dtb" ]; then
  DEVICE="R35S/R36S"
else
    DEVICE="R33S"
fi


. /usr/local/bin/buttonmon.sh

printf "\nAre you sure you want to default your PPSSPP controls?\n"
printf "\nPress A to continue.  Press B to exit.\n"
while true
do
    Test_Button_A
    if [ "$?" -eq "10" ]; then
	  rm -f /roms/psp/ppsspp/PSP/SYSTEM/controls.ini
	  rm -f /roms/psp/ppsspp/PSP/SYSTEM/ppsspp.ini
	  rm -f /roms/psp/ppsspp/PSP/SYSTEM/ppsspp.ini.sdl
	  if [ -d "/roms2/psp" ]; then
	    rm -f /roms2/psp/ppsspp/PSP/SYSTEM/controls.ini
	    rm -f /roms2/psp/ppsspp/PSP/SYSTEM/ppsspp.ini
	    rm -f /roms2/psp/ppsspp/PSP/SYSTEM/ppsspp.ini.sdl
	  fi
      if [ $? == 0 ]; then
        printf "\nRestored the default PPSSPP controls for the\n"
        printf "$DEVICE"
        sleep 5
      else
        printf "\nFailed to restore the default PPSSPP controls for $DEVICE"
        sleep 5
      fi
      exit 0
	fi

    Test_Button_B
    if [ "$?" -eq "10" ]; then
	  printf "\nExiting without defaulting the PPSSPP controls."
	  sleep 1
      exit 0
	fi
done
