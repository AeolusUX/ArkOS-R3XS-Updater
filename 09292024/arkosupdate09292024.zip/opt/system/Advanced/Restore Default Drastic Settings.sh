#!/bin/bash

DEVICE=""
CONFIG=""

if [ -f "/boot/rk3326-rg351mp-linux.dtb" ] || [ -f "/boot/rk3326-r35s-linux.dtb" ] || [ -f "/boot/rk3326-r36s-linux.dtb" ]; then
  DEVICE="R35S/R36S"
  CONFIG="drastic.cfg.351mp"
else
  DEVICE="R33S"
  CONFIG="drastic.cfg.r33s"
fi

. /usr/local/bin/buttonmon.sh

printf "\nAre you sure you want to default your drastic configuration?\n"
printf "\nPress A to continue.  Press B to exit.\n"
while true
do
    Test_Button_A
    if [ "$?" -eq "10" ]; then
      cp -f /opt/drastic/config/backup/${CONFIG} /opt/drastic/config/drastic.cfg
      if [ $? == 0 ]; then
        printf "\nRestored the default drastic emulator configuration for the\n"
        printf "$DEVICE"
        sleep 5
      else
        printf "\nFailed to restore the default drastic emulator configuration for $DEVICE"
        sleep 5
      fi
      exit 0
	fi

    Test_Button_B
    if [ "$?" -eq "10" ]; then
	  printf "\nExiting without defaulting the drastic emulator configuration."
	  sleep 1
      exit 0
	fi
done
