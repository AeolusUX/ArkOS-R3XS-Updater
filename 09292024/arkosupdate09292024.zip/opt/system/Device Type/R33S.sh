#!/bin/bash


. /usr/local/bin/buttonmon.sh

printf "\nAre you sure you want to set device type to R35S/R36S?\n"
printf "\nPress A to continue.  Press B to exit.\n"
while true
do
    Test_Button_A
    if [ "$?" -eq "10" ]; then
      cp -f /opt/drastic/config/backup/drastic.cfg.rg351mp /opt/drastic/config/drastic.cfg
	  sudo cp -f /usr/local/bin/ogage.r33s /usr/local/bin/ogage
	  sudo chmod 777 /usr/local/bin/ogage
	  sudo systemctl start emulationstation
	    rm -f /roms/psp/ppsspp/PSP/SYSTEM/controls.ini
	    rm -f /roms/psp/ppsspp/PSP/SYSTEM/ppsspp.ini
	    rm -f /roms/psp/ppsspp/PSP/SYSTEM/ppsspp.ini.sdl
	  if [ -d "/roms2/psp" ]; then
	    rm -f /roms2/psp/ppsspp/PSP/SYSTEM/controls.ini
	    rm -f /roms2/psp/ppsspp/PSP/SYSTEM/ppsspp.ini
	    rm -f /roms2/psp/ppsspp/PSP/SYSTEM/ppsspp.ini.sdl
      if [ $? == 0 ]; then
	  
        printf "\nSuccesfully set the default controls on standalone emulators for the\n"
        printf "R35S/R36S"
        sleep 5
      else
        printf "\nFailed to set the default controls on standalone emulators for the R35S/R36S"
        sleep 5
      fi
      exit 0
	fi

    Test_Button_B
    if [ "$?" -eq "10" ]; then
	  printf "\nExiting without setting device type to R35S/R36S"
	  sleep 1
      exit 0
	fi
done