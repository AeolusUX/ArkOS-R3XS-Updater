#!/bin/bash

. /usr/local/bin/buttonmon.sh

printf "\nAre you sure you want to set device type to R35S/R36S?\n"
printf "\nPress A to continue.  Press B to exit.\n"

while true; do
    Test_Button_A
    if [ "$?" -eq "10" ]; then
        cp -f /opt/drastic/config/backup/drastic.cfg.351mp /opt/drastic/config/drastic.cfg
	sudo systemctl stop oga_events
        sudo cp -f /usr/local/bin/ogage.r36s /usr/local/bin/ogage
        sudo chmod 777 /usr/local/bin/ogage
	sudo systemctl start oga_events
        sudo systemctl start emulationstation
        
        rm -f /roms/psp/ppsspp/PSP/SYSTEM/controls.ini
        rm -f /roms/psp/ppsspp/PSP/SYSTEM/ppsspp.ini
        rm -f /roms/psp/ppsspp/PSP/SYSTEM/ppsspp.ini.sdl
        
        if [ -d "/roms2/psp" ]; then
            rm -f /roms2/psp/ppsspp/PSP/SYSTEM/controls.ini
            rm -f /roms2/psp/ppsspp/PSP/SYSTEM/ppsspp.ini
            rm -f /roms2/psp/ppsspp/PSP/SYSTEM/ppsspp.ini.sdl
        fi

        if [ $? -eq 0 ]; then
            printf "\nSuccessfully set the default controls on standalone emulators for the R35S/R36S\n"
            sleep 5
        else
            printf "\nFailed to set the default controls on standalone emulators for the R35S/R36S\n"
            sleep 5
        fi
        exit 0
    fi

    Test_Button_B
    if [ "$?" -eq "10" ]; then
        printf "\nExiting without setting device type to R35S/R36S\n"
        sleep 1
        exit 0
    fi
done
