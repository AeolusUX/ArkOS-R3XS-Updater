#!/bin/bash

clear

DEVICE=""

if [ -f "/boot/rk3566.dtb" ] || [ -f "/boot/rk3566-OC.dtb" ]; then
  if [ "$(cat ~/.config/.DEVICE)" == "RG353M" ]; then
    DEVICE="rg503"
  elif [ "$(cat ~/.config/.DEVICE)" == "RG353V" ]; then
    DEVICE="rg353v"
  elif [ "$(cat ~/.config/.DEVICE)" == "RK2023" ]; then
    DEVICE="rg503"
  elif [ "$(cat ~/.config/.DEVICE)" == "RGB30" ]; then
    DEVICE="rg503"
  elif [ "$(cat ~/.config/.DEVICE)" == "RG503" ]; then
    DEVICE="rg503"
  else
    echo "This device is not compatible with this process."
	echo "Exiting..."
	sleep 3
	exit 1
  fi
fi

. /usr/local/bin/buttonmon.sh

echo "The purpose of this tool to fix no sound issues"
echo "if related to a software configuration issue"
echo "in this ArkOS installation."
echo ""
echo "Are you sure you want to fix Audio? Be aware"
echo "that this will reset audio to come out from"
echo "this device's speakers and any currently connected"
echo "headphones will need to be disconnected and reconnected"
echo "upon completion of this process."
echo ""
echo "Press A to continue.  Press B to exit."
while true
do
    Test_Button_A
    if [ "$?" -eq "10" ]; then
      sudo chown ark:ark /home/ark/.asoundrc*
      cp -f /usr/local/bin/.asoundbackup/.asoundrcbak.${DEVICE} /home/ark/.asoundrcbak
      cp -f /usr/local/bin/.asoundbackup/.asoundrcbak.${DEVICE} /home/ark/.asoundrc
      sudo chown ark:ark /home/ark/.asoundrc*
      if [ "$(cat ~/.config/.DEVICE)" == "RGB30" ] || [ "$(cat ~/.config/.DEVICE)" == "RK2023" ] ; then
        amixer -q sset 'Playback Path' HP
      else
        amixer -q sset 'Playback Path' SPK
      fi
      printf "\nFixed audio process completed.\n"
      printf "Emulationstation will now be restarted.."
      sleep 3
      sudo systemctl restart emulationstation
      printf "\033[0m"
      exit 0
    fi

    Test_Button_B
    if [ "$?" -eq "10" ]; then
      echo "Exiting without fixing audio"
	  sleep 1
      printf "\033[0m"
	  exit 0
	fi
done

