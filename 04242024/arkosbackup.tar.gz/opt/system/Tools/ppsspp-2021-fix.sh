#!/bin/bash
sudo chmod -v 755 /opt/ppsspp-2021/PPSSPPSDL*
sudo rm -f /opt/system/Tools/ppsspp-2021-fix.sh
printf "Rebooting now..."
sleep 3
sudo reboot
