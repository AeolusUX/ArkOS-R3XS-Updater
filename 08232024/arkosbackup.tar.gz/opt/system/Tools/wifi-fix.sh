#!/bin/bash
sudo chmod -R 755 /opt/system/Wifi.sh
sudo rm -f /opt/system/Tools/wifi-fix.sh
printf "Rebooting now..."
sleep 3
sudo reboot
