#!/bin/bash

# Script to enable/disable WiFi on the R36S console under ArkOS AeUX

CURR_TTY="/dev/tty1"

sudo chmod 666 $CURR_TTY
reset

# Hide cursor
printf "\e[?25l" > $CURR_TTY
dialog --clear

export TERM=linux
export XDG_RUNTIME_DIR=/run/user/$UID/

if [[ ! -e "/dev/input/by-path/platform-odroidgo2-joypad-event-joystick" ]]; then
    sudo setfont /usr/share/consolefonts/Lat7-TerminusBold22x11.psf.gz
else
    sudo setfont /usr/share/consolefonts/Lat7-Terminus16.psf.gz
fi

pgrep -f gptokeyb | sudo xargs kill -9
pgrep -f osk.py | sudo xargs kill -9
printf "\033c" > $CURR_TTY
printf "Starting Wifi Manager. Please wait..." > $CURR_TTY

height="15"
width="55"

BACKTITLE="Wi-Fi Management - R36S - By Jason"

WIFI_STATUS=$(nmcli radio wifi)
WIFI_CONFIG_FILE="/etc/wifi-status"

# Check and load Wi-Fi state from the configuration file
if [[ -f "$WIFI_CONFIG_FILE" ]]; then
    SAVED_WIFI_STATUS=$(cat "$WIFI_CONFIG_FILE")
else
    SAVED_WIFI_STATUS="disabled"
fi

# Apply the saved state on startup
if [[ "$SAVED_WIFI_STATUS" == "enabled" ]]; then
   sudo nmcli radio wifi on
else
   sudo nmcli radio wifi off
fi

# Update Wi-Fi status after modification
update_wifi_status() {
    WIFI_STATUS=$(nmcli radio wifi)
    if [[ "$WIFI_STATUS" == "enabled" ]]; then
        echo "enabled" | sudo tee "$WIFI_CONFIG_FILE" > /dev/null
    else
        echo "disabled" | sudo tee "$WIFI_CONFIG_FILE" > /dev/null
    fi
}

# Function to enable Wi-Fi
enable_wifi() {
    dialog --infobox "Enabling WiFi..." 3 40 > $CURR_TTY
    sleep 2
    sudo nmcli radio wifi on
    update_wifi_status
    dialog --msgbox "Wi-Fi successfully activated!" 6 40 > "$CURR_TTY"
    printf "\033c" > "$CURR_TTY"
    pgrep -f gptokeyb | sudo xargs kill -9
    
    # Restart EmulationStation properly
    sudo systemctl restart emulationstation &  # Run in background to avoid blocking

    exit 0
}

# Function to disable Wi-Fi
disable_wifi() {
    dialog --infobox "Disabling WiFi..." 3 40 > $CURR_TTY
    sleep 2
    sudo nmcli radio wifi off
    update_wifi_status
    dialog --msgbox "Wi-Fi successfully disabled!" 6 40 > "$CURR_TTY"
    printf "\033c" > "$CURR_TTY"
    pgrep -f gptokeyb | sudo xargs kill -9
    exit 0
}

# Set title based on Wi-Fi status
if [[ "$WIFI_STATUS" == "enabled" ]]; then
    TITLE="Wi-Fi: Enable"
else
    TITLE="Wi-Fi: Disable"
fi

# Display the main menu
MainMenu() {
  while true; do
    mainselection=(dialog \
        --backtitle "$BACKTITLE" \
        --title "Wi-Fi Manager - $TITLE" \
        --clear \
        --cancel-label "Exit" \
        --menu "Select an option:" 15 50 10)
    mainoptions=(
        1 "Enable Wi-Fi"
        2 "Disable Wi-Fi"
    )
    mainchoices=$("${mainselection[@]}" "${mainoptions[@]}" 2>&1 > "$CURR_TTY")
    
    if [[ $? != 0 ]]; then
      exit 1
    fi

    case $mainchoices in
        1) enable_wifi ;;
        2) disable_wifi ;;
    esac
  done
}

# Joystick control (if applicable)
sudo chmod 666 /dev/uinput
export SDL_GAMECONTROLLERCONFIG_FILE="/opt/inttools/gamecontrollerdb.txt"
pgrep -f gptokeyb > /dev/null && pgrep -f gptokeyb | sudo xargs kill -9
/opt/inttools/gptokeyb -1 "wifi-toggle.sh" -c "/opt/inttools/keys.gptk" > /dev/null 2>&1 &
printf "\033c" > $CURR_TTY

dialog --clear

trap exit EXIT

# Launch the main menu
MainMenu