#define APPLEWIN_VERSION 1,30,18,0

#define xstr(a) str(a)
#define str(a) #a
#define APPLEWIN_VERSION_STR xstr(APPLEWIN_VERSION)
