#!/bin/bash
sudo chmod -v 755 /opt/system/Advanced/Switch to SD2 for Roms.sh
sudo rm -f /opt/system/Tools/sd2scriptfix.sh
printf "Rebooting now..."
sleep 3
sudo reboot
