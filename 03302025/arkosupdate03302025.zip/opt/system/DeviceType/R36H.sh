#!/bin/bash

. /usr/local/bin/buttonmon.sh

printf "\nAre you sure you want to set device type to R36H?\n"
printf "\nPress A to continue.  Press B to exit.\n"

while true; do
    Test_Button_A
    if [ "$?" -eq "10" ]; then
        cp -f /opt/drastic/config/backup/drastic.cfg.r33s /opt/drastic/config/drastic.cfg
	sudo systemctl stop oga_events
        sudo cp -f /usr/local/bin/ogage.351mp /usr/local/bin/ogage
        sudo chmod 777 /usr/local/bin/ogage
	sudo systemctl start oga_events
        sudo systemctl start emulationstation
        
        cp -f /opt/ppsspp/backupsforromsfolder/r33s/controls.ini /roms/psp/ppsspp/PSP/SYSTEM/controls.ini
        cp -f /opt/ppsspp/backupsforromsfolder/r33s/ppsspp.ini /roms/psp/ppsspp/PSP/SYSTEM/ppsspp.ini
        cp -f /opt/ppsspp/backupsforromsfolder/r33s/ppsspp.ini.sdl /roms/psp/ppsspp/PSP/SYSTEM/ppsspp.ini.sdl
        cp -f /home/ark/.config/retroarch/retroarch.r36h /home/ark/.config/retroarch/retroarch.cfg
		cp -f /home/ark/.config/retroarch32/retroarch.r36h /home/ark/.config/retroarch32/retroarch.cfg
		
        if [ -d "/roms2/psp" ]; then
            cp -f /opt/ppsspp/backupsforromsfolder/r33s/controls.ini /roms2/psp/ppsspp/PSP/SYSTEM/controls.ini
            cp -f /opt/ppsspp/backupsforromsfolder/r33s/ppsspp.ini /roms2/psp/ppsspp/PSP/SYSTEM/ppsspp.ini
            cp -f /opt/ppsspp/backupsforromsfolder/r33s/ppsspp.ini.sdl /roms2/psp/ppsspp/PSP/SYSTEM/ppsspp.ini.sdl
        fi

        if [ $? -eq 0 ]; then
            printf "\nSuccessfully set the default controls on standalone emulators for the\n"
            printf "R36H\n"
            sleep 5
        else
            printf "\nFailed to set the default controls on standalone emulators for the R36H\n"
            sleep 5
        fi
        exit 0
    fi

    Test_Button_B
    if [ "$?" -eq "10" ]; then
        printf "\nExiting without setting device type to R33H\n"
        sleep 1
        exit 0
    fi
done
